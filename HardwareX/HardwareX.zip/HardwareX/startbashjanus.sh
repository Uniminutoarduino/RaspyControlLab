#!/bin/bash

sudo /opt/janus/bin/janus -F /opt/janus/etc/janus
