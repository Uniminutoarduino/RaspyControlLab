#!/bin/bash


sudo node /home/pi/Desktop/HardwareX/servidorwsHX.js
