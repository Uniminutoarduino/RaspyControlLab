#!usr/bin/python3
import redis
r = redis.Redis(host='raspberrypi', port=6379, db=0)#Database '0' in host and port.
#These functions send data to redis database. Next data are plotted. 
def plot1m(sample): 
    r.set('S1Plot', sample)
    
def plot2m(sample1,sample2):
    r.set('S1Plot', sample1+';'+sample2)
    
def plot3m(sample1,sample2,sample3):
    r.set('S1Plot', sample1+';'+sample2+';'+sample3)  
